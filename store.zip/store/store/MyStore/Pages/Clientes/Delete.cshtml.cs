using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyStore.Pages.Clientes
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
